# import bounce
# print(dir(bounce))
# print(bounce.fact_1.__doc__)
from bounce import *
print("=========calling_1.py is runnung===========")
var=odd_even(7)
print(var)