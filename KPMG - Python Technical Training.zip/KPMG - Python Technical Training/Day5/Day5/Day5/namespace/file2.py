import file1 
print("This is file2 and namespace return:-",__name__)