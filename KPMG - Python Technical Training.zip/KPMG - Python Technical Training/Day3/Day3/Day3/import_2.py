import math as coco
print(dir(coco))
g=coco.factorial(6)
print(g)

h=coco.cos(coco.pi/6)
print(h)
print(coco.sqrt(3)/2)