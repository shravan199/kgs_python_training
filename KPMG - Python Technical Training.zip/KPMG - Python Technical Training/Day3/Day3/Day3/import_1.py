import math
print(dir(math))
var=5 
print(var)
a=math.pi*5**2
print(a)

b=math.sin(math.pi/6)
print(b)










# import sys 
# print(sys.builtin_module_names)

# NameError: name 'pi' is not defined
# var/object/func/class not defined with in script
#not imported from any module .