from math import pi,sin, factorial

g=pi*3**2
print(g)

f=sin(pi/3)

print(f)

g=factorial(5)
print(g)