a=[1,2,3,4,5]
print(a)
print(id(a),type(a),len(a))
print("======Update======")
#a[2]=99
#a.append((45,"Test",89))
#a.insert(2, [34,"Test",90,"Hello"])
# a.extend([45,89,67,90,"hello"])
# for i in [45,89,67,90,"hello"]:
#     a.append(i)
    
print(a)
print(id(a),type(a),len(a))