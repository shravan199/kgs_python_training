a=["Test",1,"Test",1.2,"Test",(1,2),"Test",[89,67],"Test","Test",56.6,"Test"]
print(a)
print(id(a),type(a),len(a))
print("==========delete=======")
#create a list of Value "Test" index numbers . ?
#[0,2,4....]
#Delete all the "Test" Values from given list ? 