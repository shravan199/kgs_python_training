from random import randint,random,uniform,randrange 
# g=randint(10,67)
# print(g)

# a=random()
# print(a)

# f=uniform(-67.90,78)
# print(f)
for i in range(10):
    a=randrange(10,22,3)
    print(a)

    