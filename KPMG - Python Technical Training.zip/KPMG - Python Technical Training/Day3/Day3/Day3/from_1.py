from math import *

g=sin(pi/6)
print(g)

f=factorial(7)
print(f)