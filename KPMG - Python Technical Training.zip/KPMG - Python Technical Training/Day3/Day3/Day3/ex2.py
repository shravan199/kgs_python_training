a=10
b=20

# while a<b:
#     
#     print(a,"Nishant")
#     a=a+1
    
    
# while a<b :
#     
#     print(b,"Nishant")
#     b=b-1

for i in [56,78,45,34,33,79,90,91]:
    if i%2!=0:
        #break
        #continue
        pass# doing nothing
        print("This is pass block")
    print(i)
    
print("Done")

name="Terst"
if name=="Test":
    pass












