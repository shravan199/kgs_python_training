a="NISHANT"
a=(10,10.8,"Nishant",(89,("Hii",)),90.78,"Test")
print(a)

b=a[-2] #90.78
print("The value is b :-",b)

# get the index number of Value Hii from given tuple a ?

a=input("enter the value:-") # STRING
print(a)
print(type(a))
a=float(a)#int(a) #str()
print(type(a))
b=a*3
print(b)
