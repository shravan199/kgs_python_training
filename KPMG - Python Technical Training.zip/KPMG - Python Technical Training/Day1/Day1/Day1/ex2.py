a,b,c=10,10.8,"Nishant"

print(a)
print(b)
print(c)

print(type(a))
print(type(b))
print(type(c))

print(id(a))
print(id(b))
print(id(c))
