# a=() #empty tuple
a=(10,10.8,"Nishant")  # tuple of more than one value

print(a)
print(id(a),type(a),len(a))   
#comments in python 

'''
Hello This Multilin ctrl+ /(?)
comments 
in  python

'''
#() #default python 
#{}
#[]
# create one value Tuple of UTKARSH ?
a= "UTKARSH", #("UTKARSH",)
print(a)
print(id(a),type(a),len(a))   