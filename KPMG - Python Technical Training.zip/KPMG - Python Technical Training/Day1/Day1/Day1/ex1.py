a=b=c="Nishant"
print(a)
print(b)
print(c)

print(type(a))

print(id(a))
print(id(b))
print(id(c))