name="Manish"
surname="Meena"

if name=="Manish":
	print("The name matched")
      	if surname=="Meena":
		print("NAme and surname matched!")

else:
	print("Name not matched!")