a=input("Enter the value:-")#
print(a)#string

b=a*3
print(b)