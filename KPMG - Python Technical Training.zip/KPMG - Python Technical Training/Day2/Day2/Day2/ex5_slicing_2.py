a="NISHANT"
a="NISHANT Sharma"
a=(10,10.8,"Nishant",(89,("Hii",)),90.78,"Test")
print(a)
# reverse the whole seq and fill the value of X and Y with logic of slicing ?
b=a[-1:-(len(a)+1):-1]
print(b)