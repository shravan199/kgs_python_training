a=("Nishant",1,1.5,[56,89])
print(a,type(a),id(a))
b=("Nishant",1,1.5,[56,89])
print(b,type(b),id(b))

print(a==b)