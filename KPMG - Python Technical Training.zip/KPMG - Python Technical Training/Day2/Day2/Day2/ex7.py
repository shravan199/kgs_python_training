a=(1,2,3)
b=(4,5)
c=a+b 
print(c)

v="Nishant"
age=89 
m=v+" "+str(age)
print(m)

print(m*4)
print(a*3)