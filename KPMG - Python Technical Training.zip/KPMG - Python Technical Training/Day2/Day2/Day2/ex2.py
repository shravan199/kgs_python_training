a="NISHANT"
print(a)

b=a[4]
print(b)
# try to update the char of an string object
#a[4]="P"
# TypeError: 'str' object does not support item assignment
del a[4]
#TypeError: 'str' object doesn't support item deletion