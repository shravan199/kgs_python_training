# import bin.bounce
# print(dir(bin.bounce))
# print(bin.bounce.fact_1.__doc__)
from bin.bounce import *
var=odd_even(7)
print(var)