d={}
d={"name":"Nishant","Age":67,("Dept","others"):"l&D",98575.67:"hdbv#55625632bhvdsgh",
   "name":["Naresh","Suresh"]}

# d=dict(key1=value1,key=value2,.....)
#d=dict(name="Nishant",age=89,dept="L&D",_888878="Test")
print(d)
print(id(d),type(d),len(d))

