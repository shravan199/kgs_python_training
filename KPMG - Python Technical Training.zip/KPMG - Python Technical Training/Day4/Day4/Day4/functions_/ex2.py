"""
This is details method
"""
def details(firstname="Jk",lastname="Tata",age=16):
    name=firstname+' '+lastname 
    return name,age


v=details('Manish',age=78,lastname="Meena")
print(v)

m=details()
print(m)

# 
# v=details()
# print(v)

